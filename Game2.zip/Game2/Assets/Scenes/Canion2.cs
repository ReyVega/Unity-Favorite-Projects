﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Canion2 : MonoBehaviour
{
    public GameObject original;
    public Transform referencia;

    // Start is called before the first frame update
    void Start()
    {


    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            transform.Rotate(30 * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.Rotate(-1 * 30 * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(1 * 5 * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(-1 * 5 * Time.deltaTime, 0, 0);
        }
       
        if (Input.GetKeyUp(KeyCode.F))
        {
            Instantiate(original, referencia.position, referencia.rotation);
        }
    }
}
