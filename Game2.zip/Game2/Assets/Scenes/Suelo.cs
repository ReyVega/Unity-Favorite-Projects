﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Suelo : MonoBehaviour
{
    private Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();

        Rigidbody[] rbs = GetComponents<Rigidbody>();


    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        
        if (!(collision.gameObject.name == "Canion" || collision.gameObject.name == "Canion2")) {
            Destroy(gameObject, .4f);
        }
       
        
        
    }
}
