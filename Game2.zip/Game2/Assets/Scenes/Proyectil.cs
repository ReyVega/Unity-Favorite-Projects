﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Proyectil : MonoBehaviour
{
    //recuperar una referencia a un rigid body 
    private Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        //code para obtener la referencia, puede regresar null
        rb = GetComponent<Rigidbody>();

        Rigidbody[] rbs = GetComponents<Rigidbody>();
        // # vectores
        // -up
        // -forward
        // - right
        rb.AddForce(transform.up * 50, ForceMode.Impulse);
        Destroy(gameObject, 10);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {

        if (collision.gameObject.name == "Canion2" || collision.gameObject.name == "Canion") {
            Destroy(collision.gameObject, .4f);
        }
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
    }
}
