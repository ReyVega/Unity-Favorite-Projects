﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemigo2 : MonoBehaviour
{
    public bool dirRight = true;
    public int speed = 25;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (dirRight)
        {
            transform.Translate(Vector2.right * speed * Time.deltaTime);
        }
        else
        {
            transform.Translate(-Vector2.right * speed * Time.deltaTime);
        }
        if (transform.position.x >= 2)
        {
            dirRight = false;
        }

        if (transform.position.x <= -14.5f)
        {
            dirRight = true;
        }

    }

    private void OnCollisionEnter(Collision collision)
    {
        Score.score -= 20;
    }
}
