﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Score : MonoBehaviour
{

    public Text texto;
    public static int score = 0;

    // Use this for initialization
    void Start()
    {
    }


    // Update is called once per frame
    void Update()
    {

        texto.text = "Score: " + score;

    }
}
