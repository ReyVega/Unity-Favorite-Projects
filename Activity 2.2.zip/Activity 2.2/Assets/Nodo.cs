﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nodo : MonoBehaviour
{
    public Nodo[] vecinos;
    public List<Nodo> historial;
    public static bool key = true;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = new Color(0,28,0);
        for (int i = 0; i < vecinos.Length; i++)
        {
            if (vecinos[i] != null)
            {
                Gizmos.DrawLine(transform.position, vecinos[i].transform.position);
            }
        }
        Gizmos.color = Color.blue;
        Gizmos.DrawSphere(transform.position,1f);
    }

    private void OnMouseDown()
    {
        if (key) {
            Personaje.fin = this;
            Personaje.key = true;
            key = false;
        }
    }
}
