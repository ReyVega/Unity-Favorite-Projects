﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Personaje : MonoBehaviour
{
    public int speed = 0;

    private int current;

    public Nodo inicio;

    public static Nodo fin;

    private float waitTime;

    public float startWaitTime;
    public static bool key = false;
    private bool   key2 = false;

    private List<Nodo> nodos = new List<Nodo>();


    // Start is called before the first frame update
    void Start()
    {
        waitTime = startWaitTime;
    }

    // Update is called once per frame
    void Update()
    {
        if (key) {
            List<Nodo> ruta = PathFinding.Profundo(inicio,fin);

            foreach (Nodo actual in ruta)
            {
                print(actual.transform.name);
                nodos.Add(actual);
            }
            key = false;
            key2 = true;
        }

        if (key2) {
            transform.position = Vector3.MoveTowards(transform.position, nodos[current].transform.position, speed *
                          Time.deltaTime);
            if (Vector3.Distance(transform.position, nodos[current].transform.position) < 0.2f)
            {
                if (waitTime <= 0)
                {
                    if (current < nodos.Count - 1)
                    {
                        current++;
                        waitTime = startWaitTime;
                    }
                    else {
                        nodos.Clear();
                        current = 0;
                        transform.position = inicio.transform.position;
                        key2 = false;
                        Nodo.key = true;
                    }
                }
                else
                {
                    waitTime -= Time.deltaTime;
                }
            }
        }
    }

       
   
}
