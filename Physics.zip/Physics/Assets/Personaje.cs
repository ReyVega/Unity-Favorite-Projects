﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Personaje : MonoBehaviour {

    //atributos públicos
    //clases de Unity
    // primitivos

    public float speed = 3;
    public Text textito; 

    //Ciclo de Vida

    //Sucede al inicio de la creación del personaje
    //Una sola vez
    void Awake(){
        print("UwU");
    }

    //Sucede después de Awake
    //una sola vez 
    //Start solo corre si el comoponente está habilitado
    // Start is called before the first frame update
    void Start(){
        print("n.n");
        textito.text = "BUENOS DIAS AMIWITOS ZOY NUEVO";
    }

    // Corre con el ciclo del juego 
    // va a correr tanto como pueda 
    // 30 fps - app a tiempo real
    // 60 fps lo bueno de verdad xd
    // Usar para entrada de usuario
    // Usar para movimiento
    // Update is called once per frame
    void Update() {
        //Entrada general en 2 categorías:
        //Polling: Sondeo
        //Events: Listeners

        //Todo es polling aquí:
        //2 maneras de obtener la entrada del usuario
        //1 - directo al dispositivo
        //2 - usando ejes
        if (Input.GetKeyDown(KeyCode.Space)){
            //true si en frame anterior estaba libre y en el actual no 
            print("Down");
        }

        if (Input.GetKey(KeyCode.Space))
        {
            //true si en frame anterior estaba libre y en el actual no 
            print("Pressed");
        }

        if (Input.GetKeyUp(KeyCode.Space))
        {
            //true si en frame anterior estaba libre y en el actual no 
            print("UP");
        }

        if (Input.GetMouseButtonDown(0))
        {
            print(Input.mousePosition);
        }

        //Por medio de Ejes 
        //Ejes abstracción de n dispositivo de entrada
        //Siempre regresan un valor flotante entre -1 y 1

        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        //print(h);

        //Transform -clase que define al componente
        //transform - objeto prepoblado con un referencia al transform del mismo gameobject 

        
        transform.Translate(speed*h*Time.deltaTime, speed* v * Time.deltaTime, 0, Space.World);
        
    }
    void LateUpdate(){
        //print("LateUpdate");
    }

    //Frecuencia "constante"
    //
    void FixedUpdate(){
        //print("Fixed");
    }

    //detección de colisión a nivel de código

    void OnCollisionEnter(Collision collision)
    {
        print("Ooof " + collision.transform.name + "My: " + collision.contacts[0]);
    }

    void OnCollisionStay(Collision collision)
    {
        print("Ouch " + collision.transform.name + "My: " + collision.contacts[0] );
    }

    void OnCollisionExit(Collision collision)
    {
        print("Owie " + collision.transform.name );
    }

    void OnTriggerEnter(Collider c)
    {
        print(c.transform.name);
    }

    void OnTriggerStay(Collider c)
    {
        print(c.transform.name);
    }

    void OnTriggerExit(Collider c)
    {
        print(c.transform.name);
    }

}
