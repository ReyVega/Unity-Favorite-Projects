﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StateMachine : MonoBehaviour
{
    //Carta random
    public MonoBehaviour EstadoPrimerTurno;
    //(Si gano) utilizar una carta de un elemento distinto al usado
    public MonoBehaviour EstadoGanado;
    //(Si perdió) utilizar hielo si el oponente uso fuego, usar fuego si el oponente uso agua, usar agua si el oponente uso hielo
    public MonoBehaviour EstadoPerdio;
    //Cuando le falta un elemento para ganar , 80% de probabilidad de usar ese elemento que le falta
    public MonoBehaviour EstadoVictorioso;
    //Cuando al jugador le falta un elemento, 80% de probabilidad de utilizar el elemento que le gana al que le hace falta al jugador
    public MonoBehaviour EstadoAgresivo;

    private MonoBehaviour estadoActual;


    // Start is called before the first frame update
    void Start()
    {
        activarEstado(EstadoPrimerTurno);
    }
    
    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.A)) {
            activarEstado(EstadoGanado);
        }
        if (Input.GetKeyDown(KeyCode.B)) {
            activarEstado(EstadoPerdio);
        }
        if (Input.GetKeyDown(KeyCode.C)) {
            activarEstado(EstadoAgresivo);
        }
    }

    public void activarEstado(MonoBehaviour nuevoEstado)
    {
        if (estadoActual != null)
        {
            estadoActual.enabled = false;
        }
        estadoActual = nuevoEstado;
        estadoActual.enabled = true;
    }
}
