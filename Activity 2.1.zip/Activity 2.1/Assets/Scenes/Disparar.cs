﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disparar : MonoBehaviour
{

    public GameObject original;
    public Transform referencia;
    public float fuerzaBala = 20f;
    public static bool key = true;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (key) {
            if (Input.GetMouseButtonDown(0))
            {
                GameObject bala = Instantiate(original, referencia.position, referencia.rotation);
                Rigidbody2D rb = bala.GetComponent<Rigidbody2D>();
                rb.AddForce(referencia.up * fuerzaBala, ForceMode2D.Impulse);
            }
        }
    }
}
