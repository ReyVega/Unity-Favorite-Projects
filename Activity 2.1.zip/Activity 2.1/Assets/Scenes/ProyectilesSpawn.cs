﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProyectilesSpawn : MonoBehaviour
{
    public GameObject original;
    public float fuerzaProyectil = 1f;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine("proyectil");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator proyectil() {
        while (true) {
            transform.position = new Vector2(Random.Range(-8.55f, 8.55f), transform.position.y);
            GameObject bala = Instantiate(original, transform.position, transform.rotation);
            Rigidbody2D rb = bala.GetComponent<Rigidbody2D>();
            rb.AddForce(transform.up * fuerzaProyectil, ForceMode2D.Impulse);
            yield return new WaitForSeconds(3);
        }
    }

}
