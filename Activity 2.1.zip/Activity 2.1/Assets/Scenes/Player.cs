﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 5.0f;
    public Rigidbody2D rb;

    public Animator animator;
    public Camera cam;

    Vector2 movimiento;
    Vector2 mousePos;

    public static bool key = true;
    public BoxCollider2D collider;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(Mathf.Clamp(transform.position.x,-8.55f,8.55f),
                                          Mathf.Clamp(transform.position.y,-4.67f,4.67f),
                                          transform.position.z);
        if (key) {
            animator.SetFloat("Speed", Mathf.Abs(movimiento.x) + Mathf.Abs(movimiento.y));

            movimiento.x = Input.GetAxisRaw("Horizontal");
            movimiento.y = Input.GetAxisRaw("Vertical");

            mousePos = cam.ScreenToWorldPoint(Input.mousePosition);
        }
    }

    private void FixedUpdate()
    {
        if (key) {
            rb.MovePosition(rb.position + movimiento * speed * Time.fixedDeltaTime);

            Vector2 lookDir = mousePos - rb.position;
            float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
            rb.rotation = angle;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Enemigo1" || collision.gameObject.name == "Enemigo2") {
            transform.position = new Vector3(transform.position.x,transform.position.y,1);
            collider.enabled = false;
            key = false;
            Disparar.key = false;
            animator.SetBool("Muerte", true);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "Proyectil(Clone)")
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, 1);
            collider.enabled = false;
            key = false;
            Disparar.key = false;
            animator.SetBool("Muerte", true);
        }
    }
}
