﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol1 : MonoBehaviour
{
    public float speed;
    public Transform[] spots;
    private int randomSpot;
    private float waitTime;
    public float startWaitTime;
    public Animator animator;
    public static bool key = true;

    // Start is called before the first frame update
    void Start()
    {
        waitTime = startWaitTime;
        randomSpot = Random.Range(0,spots.Length);
        animator.SetBool("Movimiento", true);
    }

    // Update is called once per frame
    void Update()
    {
        if (key) {
            Vector2 lookDir = spots[randomSpot].position - transform.position;
            float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(Vector3.forward * angle);

            transform.position = Vector2.MoveTowards(transform.position, spots[randomSpot].position, speed *
                           Time.deltaTime);

            if (Vector2.Distance(transform.position, spots[randomSpot].position) < 0.2f)
            {
                if (waitTime <= 0)
                {
                    randomSpot = Random.Range(0, spots.Length);
                    waitTime = startWaitTime;
                    animator.SetBool("Movimiento", true);

                }
                else
                {
                    waitTime -= Time.deltaTime;
                    animator.SetBool("Movimiento", false);
                }
            }
        }
    }
}
